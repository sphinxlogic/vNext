using System.Reflection;
// Version 2.3.0; year 2008+6, month 10, day 16
[assembly: AssemblyVersion("2.3.0.61016")]
[assembly: AssemblyFileVersion("2.3.0.61016")]
