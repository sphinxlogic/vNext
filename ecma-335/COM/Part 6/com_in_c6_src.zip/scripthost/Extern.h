#ifdef __cplusplus
extern "C" {
#endif

// Functions
extern void		display_COM_error(LPCTSTR, HRESULT);

#ifdef __cplusplus
}
#endif
