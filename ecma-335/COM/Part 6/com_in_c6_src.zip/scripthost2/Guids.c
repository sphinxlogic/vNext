// Defines the GUIDs used in our application.

#include <initguid.h>