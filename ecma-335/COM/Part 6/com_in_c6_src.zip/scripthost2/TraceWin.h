#ifndef TRACEWIN_H
#define TRACEWIN_H

#ifdef __cplusplus
extern "C" {
#endif

extern void traceEnterFunc(LPCTSTR);
extern void traceShowArgs(LPCTSTR, DWORD, VARIANT *);
extern void traceShowState(DWORD, DWORD);
extern void traceShowInt(LPCTSTR, DWORD);
extern void traceShowStr(LPCTSTR, LPCOLESTR);
extern void traceShowWStr(LPCOLESTR, DWORD);
extern void traceLeaveFunc(void);

#ifdef __cplusplus
}
#endif

#endif