#ifndef _IEXAMPLEEVTS2_H_
#define _IEXAMPLEEVTS2_H_

#include <initguid.h>

// IExampleEvts2 type library GUID
// {EF3D37CB-8CF2-4f93-BC80-275050BEC28F}
DEFINE_GUID(CLSID_TypeLib, 0xef3d37cb, 0x8cf2, 0x4f93, 0xbc, 0x80, 0x27, 0x50, 0x50, 0xbe, 0xc2, 0x8f);

// IExampleEvts2 object's GUID
// {6CD5B88D-496B-4e32-B959-1AFD03C4A81F}
DEFINE_GUID(CLSID_IExampleEvts2, 0x6cd5b88d, 0x496b, 0x4e32, 0xb9, 0x59, 0x1a, 0xfd, 0x3, 0xc4, 0xa8, 0x1f);

// IExampleEvts2 VTable's GUID
// {58B482A9-C6EA-4967-8C7C-4CFDA937657A}
DEFINE_GUID(IID_IExampleEvts2, 0x58b482a9, 0xc6ea, 0x4967, 0x8c, 0x7c, 0x4c, 0xfd, 0xa9, 0x37, 0x65, 0x7a);

// IExampleEvts's VTable
#undef  INTERFACE
#define INTERFACE IExampleEvts2
DECLARE_INTERFACE_ (INTERFACE, IDispatch)
{
	// IUnknown functions
	STDMETHOD  (QueryInterface)		(THIS_ REFIID, void **) PURE;
	STDMETHOD_ (ULONG, AddRef)		(THIS) PURE;
	STDMETHOD_ (ULONG, Release)		(THIS) PURE;
	// IDispatch functions
	STDMETHOD_ (ULONG, GetTypeInfoCount)(THIS_ UINT *) PURE;
	STDMETHOD_ (ULONG, GetTypeInfo)		(THIS_ UINT, LCID, ITypeInfo **) PURE;
	STDMETHOD_ (ULONG, GetIDsOfNames)	(THIS_ REFIID, LPOLESTR *, UINT, LCID, DISPID *) PURE;
	STDMETHOD_ (ULONG, Invoke)			(THIS_ DISPID, REFIID, LCID, WORD, DISPPARAMS *, VARIANT *, EXCEPINFO *, UINT *) PURE;
	// Extra functions
	STDMETHOD  (DoSomething)		(THIS) PURE;
};

// The IFeedback2 object must be created by an application,
// and given to IExampleEvts2 (via the Advise function of
// IExampleEvts2's IConnectPoint for an IFeedback2).

// IFeedback2 VTable's GUID
// {CF4C2EE7-999E-4f5f-83AE-9260DB8FC54A}
DEFINE_GUID(DIID_IFeedback2, 0xcf4c2ee7, 0x999e, 0x4f5f, 0x83, 0xae, 0x92, 0x60, 0xdb, 0x8f, 0xc5, 0x4a);

// IFeedback's VTable
#undef  INTERFACE
#define INTERFACE IFeedback2
DECLARE_INTERFACE_ (INTERFACE, IDispatch)
{
	// IUnknown functions
	STDMETHOD  (QueryInterface)		(THIS_ REFIID, void **) PURE;
	STDMETHOD_ (ULONG, AddRef)		(THIS) PURE;
	STDMETHOD_ (ULONG, Release)		(THIS) PURE;
	// IDispatch functions
	STDMETHOD_ (ULONG, GetTypeInfoCount)(THIS_ UINT *) PURE;
	STDMETHOD_ (ULONG, GetTypeInfo)		(THIS_ UINT, LCID, ITypeInfo **) PURE;
	STDMETHOD_ (ULONG, GetIDsOfNames)	(THIS_ REFIID, LPOLESTR *, UINT, LCID, DISPID *) PURE;
	STDMETHOD_ (ULONG, Invoke)			(THIS_ DISPID, REFIID, LCID, WORD, DISPPARAMS *, VARIANT *, EXCEPINFO *, UINT *) PURE;
	// Extra functions
	STDMETHOD  (Callback1)			(THIS) PURE;
	STDMETHOD  (Callback2)			(THIS) PURE;
	STDMETHOD  (Callback3)			(THIS) PURE;
	STDMETHOD  (Callback4)			(THIS) PURE;
	STDMETHOD  (Callback5)			(THIS) PURE;
};

#endif // _IEXAMPLEEVTS2_H_