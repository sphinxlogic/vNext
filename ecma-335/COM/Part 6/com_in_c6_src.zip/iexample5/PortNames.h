IDispatch *		allocPortsCollection(void);
void			freePortsCollection(void);
HRESULT			initPortsCollection(void);
