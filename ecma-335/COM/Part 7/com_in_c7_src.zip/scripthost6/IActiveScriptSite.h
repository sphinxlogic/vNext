#ifndef _HOSTSITE_H
#define _HOSTSITE_H

// The definition of our MyRealIActiveScriptSite multiple interface
// object. It has an IActiveScriptSite object as the base object,
// and an IActiveScriptSiteWindow sub-object.
class MyRealIActiveScriptSite : public IActiveScriptSite, public IActiveScriptSiteWindow
{
protected:
public:
	MyRealIActiveScriptSite()
	{
	}

	~MyRealIActiveScriptSite()
	{
	}

	//******* IUnknown *******
	STDMETHODIMP QueryInterface(REFIID riid, void * * ppvObj);
	STDMETHODIMP_(ULONG) AddRef();
	STDMETHODIMP_(ULONG) Release();

	//******* IActiveScriptSite *******
	STDMETHODIMP GetLCID(LCID *);
	STDMETHODIMP GetItemInfo(LPCOLESTR, DWORD, IUnknown **, ITypeInfo **);
	STDMETHODIMP GetDocVersionString(BSTR *);
	STDMETHODIMP OnScriptTerminate(const VARIANT *, const EXCEPINFO *);
	STDMETHODIMP OnStateChange(SCRIPTSTATE);
	STDMETHODIMP OnScriptError(IActiveScriptError *);
	STDMETHODIMP OnEnterScript(void);
	STDMETHODIMP OnLeaveScript(void);

	//******* IActiveScriptSiteWindow *******
	STDMETHODIMP GetWindow(HWND *);
	STDMETHODIMP EnableModeless(BOOL);
};

extern MyRealIActiveScriptSite	MyActiveScriptSite;

#endif