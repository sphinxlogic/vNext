#ifndef _IEXAMPLE5_H_
#define _IEXAMPLE5_H_

#include <initguid.h>

// IExample5 type library's GUID
// {5148D6B4-B6FF-4a3f-BCA3-604D39F62878}
DEFINE_GUID(CLSID_TypeLib, 0x5148d6b4, 0xb6ff, 0x4a3f, 0xbc, 0xa3, 0x60, 0x4d, 0x39, 0xf6, 0x28, 0x78);

// IExample5 object's GUID
// {49785E29-16DC-4fca-A0FD-C0057C140489}
DEFINE_GUID(CLSID_IExample5, 0x49785e29, 0x16dc, 0x4fca, 0xa0, 0xfd, 0xc0, 0x5, 0x7c, 0x14, 0x4, 0x89);

// IExample5 VTable's GUID
// {331829E8-A73D-49ee-9FE4-A3136C7AAD4A}
DEFINE_GUID(IID_IExample5, 0x331829e8, 0xa73d, 0x49ee, 0x9f, 0xe4, 0xa3, 0x13, 0x6c, 0x7a, 0xad, 0x4a);

// IExample5's VTable
#undef  INTERFACE
#define INTERFACE IExample5
DECLARE_INTERFACE_ (INTERFACE, IDispatch)
{
	// IUnknown functions
	STDMETHOD  (QueryInterface)		(THIS_ REFIID, void **) PURE;
	STDMETHOD_ (ULONG, AddRef)		(THIS) PURE;
	STDMETHOD_ (ULONG, Release)		(THIS) PURE;
	// IDispatch functions
	STDMETHOD_ (ULONG, GetTypeInfoCount)(THIS_ UINT *) PURE;
	STDMETHOD_ (ULONG, GetTypeInfo)		(THIS_ UINT, LCID, ITypeInfo **) PURE;
	STDMETHOD_ (ULONG, GetIDsOfNames)	(THIS_ REFIID, LPOLESTR *, UINT, LCID, DISPID *) PURE;
	STDMETHOD_ (ULONG, Invoke)			(THIS_ DISPID, REFIID, LCID, WORD, DISPPARAMS *, VARIANT *, EXCEPINFO *, UINT *) PURE;
	// Extra functions
	STDMETHOD  (SetString)			(THIS_ BSTR) PURE;
	STDMETHOD  (GetString)			(THIS_ BSTR *) PURE;
	STDMETHOD  (GetPorts)			(THIS_ IDispatch **) PURE;
	STDMETHOD  (GetNetworks)		(THIS_ IDispatch **) PURE;
};

// INetwork VTable's GUID
// {9AD84E70-57AC-4bab-B765-AE4BD3845D96}
DEFINE_GUID(IID_INetwork, 0x9ad84e70, 0x57ac, 0x4bab, 0xb7, 0x65, 0xae, 0x4b, 0xd3, 0x84, 0x5d, 0x96);

// INetwork's VTable
#undef  INTERFACE
#define INTERFACE INetwork
DECLARE_INTERFACE_ (INTERFACE, IDispatch)
{
	// IUnknown functions
	STDMETHOD  (QueryInterface)		(THIS_ REFIID, void **) PURE;
	STDMETHOD_ (ULONG, AddRef)		(THIS) PURE;
	STDMETHOD_ (ULONG, Release)		(THIS) PURE;
	// IDispatch functions
	STDMETHOD_ (ULONG, GetTypeInfoCount)(THIS_ UINT *) PURE;
	STDMETHOD_ (ULONG, GetTypeInfo)		(THIS_ UINT, LCID, ITypeInfo **) PURE;
	STDMETHOD_ (ULONG, GetIDsOfNames)	(THIS_ REFIID, LPOLESTR *, UINT, LCID, DISPID *) PURE;
	STDMETHOD_ (ULONG, Invoke)			(THIS_ DISPID, REFIID, LCID, WORD, DISPPARAMS *, VARIANT *, EXCEPINFO *, UINT *) PURE;
	// Extra functions
	STDMETHOD  (Name)				(THIS_ BSTR *) PURE;
	STDMETHOD  (Address)			(THIS_ BSTR *) PURE;
};

#endif // _IEXAMPLE5_H_
