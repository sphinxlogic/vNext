#ifndef _IEXAMPLEEVTS_H_
#define _IEXAMPLEEVTS_H_

#include <initguid.h>

// IExampleEvts object's GUID
// {207C0C3E-A535-4cca-9A50-5EF40CC23540}
DEFINE_GUID(CLSID_IExampleEvts, 0x207c0c3e, 0xa535, 0x4cca, 0x9a, 0x50, 0x5e, 0xf4, 0xc, 0xc2, 0x35, 0x40);

// IExampleEvts VTable's GUID
// {3D870108-BF79-42a1-A52F-45F16CCD87FA}
DEFINE_GUID(IID_IExampleEvts, 0x3d870108, 0xbf79, 0x42a1, 0xa5, 0x2f, 0x45, 0xf1, 0x6c, 0xcd, 0x87, 0xfa);

// IExampleEvts's VTable
#undef  INTERFACE
#define INTERFACE IExampleEvts
DECLARE_INTERFACE_ (INTERFACE, IUnknown)
{
	// IUnknown functions
	STDMETHOD  (QueryInterface)		(THIS_ REFIID, void **) PURE;
	STDMETHOD_ (ULONG, AddRef)		(THIS) PURE;
	STDMETHOD_ (ULONG, Release)		(THIS) PURE;
	// Extra functions
	STDMETHOD  (DoSomething)		(THIS) PURE;
};

// The IFeedback object must be created by an application using IExampleEvts,
// and given to IExampleEvts IConnectPoint object for an IFeedback (via
// IConnectPoint's Advise function).

// IFeedback VTable's GUID
// {4115B8E2-1823-4bbc-B10D-3D33AAA12ACF}
DEFINE_GUID(DIID_IFeedback, 0x4115b8e2, 0x1823, 0x4bbc, 0xb1, 0xd, 0x3d, 0x33, 0xaa, 0xa1, 0x2a, 0xcf);

// IFeedback's VTable
#undef  INTERFACE
#define INTERFACE IFeedback
DECLARE_INTERFACE_ (INTERFACE, IUnknown)
{
	// IUnknown functions
	STDMETHOD  (QueryInterface)		(THIS_ REFIID, void **) PURE;
	STDMETHOD_ (ULONG, AddRef)		(THIS) PURE;
	STDMETHOD_ (ULONG, Release)		(THIS) PURE;
	// Extra functions
	STDMETHOD  (Callback1)			(THIS) PURE;
	STDMETHOD  (Callback2)			(THIS) PURE;
	STDMETHOD  (Callback3)			(THIS) PURE;
	STDMETHOD  (Callback4)			(THIS) PURE;
	STDMETHOD  (Callback5)			(THIS) PURE;
};

#endif // _IEXAMPLEEVTS_H_