// Defines our GUIDs for our own objects, and the object name a
// script uses to call our application object's extra functions.
//
// You must use GUIDGEN.EXE to generate your own GUIDs when you
// create your own script host.

#include <initguid.h>

// Our IApp object GUID
const CLSID CLSID_IApp = {0xCD19DEC3,0x3B5A,0x11d0,{0xB3,0x9A,0x00,0x80,0xC7,0xBC,0x78,0x84}};

// Our IApp VTable's GUID
const IID IID_IApp = {0xCD19DEC1,0x3B5A,0x11d0,{0xB3,0x9A,0x00,0x80,0xC7,0xBC,0x78,0x84}};

// The name that a script uses to access our application object
const wchar_t	MyAppObjectName[] =	L"application";
