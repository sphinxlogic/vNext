#ifdef __cplusplus
extern "C" {
#endif

extern const CLSID CLSID_IApp;
extern const IID IID_IApp;
extern const wchar_t MyAppObjectName[];

#ifdef __cplusplus
}
#endif
