#ifndef _IMULTINTERFACE_H_
#define _IMULTINTERFACE_H_

#include <initguid.h>

// Our IMultInterface object's GUID
// {724CBEA7-DD5F-4cfc-AC4B-32635728D4BC}
DEFINE_GUID(CLSID_IMultInterface, 0x724cbea7, 0xdd5f, 0x4cfc, 0xac, 0x4b, 0x32, 0x63, 0x57, 0x28, 0xd4, 0xbc);

// Our IMultInterface's VTable GUID
// {442AD887-8D70-4647-9ED3-C997A384F3B1}
DEFINE_GUID(IID_IMultInterface, 0x442ad887, 0x8d70, 0x4647, 0x9e, 0xd3, 0xc9, 0x97, 0xa3, 0x84, 0xf3, 0xb1);

// Our IBase VTable's GUID
// {28B1673B-275B-43e9-A56A-37FA8A92A1C7}
DEFINE_GUID(IID_IBase, 0x28b1673b, 0x275b, 0x43e9, 0xa5, 0x6a, 0x37, 0xfa, 0x8a, 0x92, 0xa1, 0xc7);

// Defines IBase's functions
#undef  INTERFACE
#define INTERFACE  IBase
DECLARE_INTERFACE_ (INTERFACE, IUnknown)
{
	STDMETHOD  (QueryInterface)		(THIS_ REFIID, void **) PURE;
	STDMETHOD_ (ULONG, AddRef)		(THIS) PURE;
	STDMETHOD_ (ULONG, Release)		(THIS) PURE;
	STDMETHOD  (Sum)			(THIS_ long, long, long *) PURE;
};

// Our ISub1 VTable's GUID
// {41835393-85AE-4d55-84E9-6E18102379D0}
DEFINE_GUID(IID_ISub1, 0x41835393, 0x85ae, 0x4d55, 0x84, 0xe9, 0x6e, 0x18, 0x10, 0x23, 0x79, 0xd0);

// Defines ISub1's functions
#undef  INTERFACE
#define INTERFACE  ISub1
DECLARE_INTERFACE_ (INTERFACE, IUnknown)
{
	STDMETHOD  (QueryInterface)		(THIS_ REFIID, void **) PURE;
	STDMETHOD_ (ULONG, AddRef)		(THIS) PURE;
	STDMETHOD_ (ULONG, Release)		(THIS) PURE;
	STDMETHOD  (ShowMessage)		(THIS_ char *) PURE;
};

// Our ISub2 VTable's GUID
// {CB97AD00-C8CB-41c6-93B2-9E56B1DFDD98}
DEFINE_GUID(IID_ISub2, 0xcb97ad00, 0xc8cb, 0x41c6, 0x93, 0xb2, 0x9e, 0x56, 0xb1, 0xdf, 0xdd, 0x98);

// Defines ISub2's functions
#undef  INTERFACE
#define INTERFACE  ISub2
DECLARE_INTERFACE_ (INTERFACE, IUnknown)
{
	STDMETHOD  (QueryInterface)		(THIS_ REFIID, void **) PURE;
	STDMETHOD_ (ULONG, AddRef)		(THIS) PURE;
	STDMETHOD_ (ULONG, Release)		(THIS) PURE;
	STDMETHOD  (Increment)			(THIS) PURE;
	STDMETHOD  (Decrement)			(THIS) PURE;
	STDMETHOD  (GetValue)			(THIS_ long *) PURE;
};

#endif // _IMULTINTERFACE_H_
