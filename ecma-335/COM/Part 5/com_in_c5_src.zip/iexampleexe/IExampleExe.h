#ifndef _IEXAMPLEEXE_H_
#define _IEXAMPLEEXE_H_

#include <initguid.h>

// IExampleExe type library's GUID
// {4370990C-5481-4901-BF01-CF0F298D923C}
DEFINE_GUID(CLSID_TypeLib, 0x4370990c, 0x5481, 0x4901, 0xbf, 0x1, 0xcf, 0xf, 0x29, 0x8d, 0x92, 0x3c);

// IExampleExe object's GUID
// {30D789C0-553A-4f36-A13B-807A3003FDC0}
DEFINE_GUID(CLSID_IExampleExe, 0x30d789c0, 0x553a, 0x4f36, 0xa1, 0x3b, 0x80, 0x7a, 0x30, 0x3, 0xfd, 0xc0);

// IExampleExe VTable's GUID
// {112BD761-DE08-4e94-95F7-473E3CEFE26A}
DEFINE_GUID(IID_IExampleExe, 0x112bd761, 0xde08, 0x4e94, 0x95, 0xf7, 0x47, 0x3e, 0x3c, 0xef, 0xe2, 0x6a);

// IExampleExe's VTable
#undef  INTERFACE
#define INTERFACE IExampleExe
DECLARE_INTERFACE_ (INTERFACE, IDispatch)
{
	// IUnknown functions
	STDMETHOD  (QueryInterface)		(THIS_ REFIID, void **) PURE;
	STDMETHOD_ (ULONG, AddRef)		(THIS) PURE;
	STDMETHOD_ (ULONG, Release)		(THIS) PURE;
	// IDispatch functions
	STDMETHOD_ (ULONG, GetTypeInfoCount)(THIS_ UINT *) PURE;
	STDMETHOD_ (ULONG, GetTypeInfo)		(THIS_ UINT, LCID, ITypeInfo **) PURE;
	STDMETHOD_ (ULONG, GetIDsOfNames)	(THIS_ REFIID, LPOLESTR *, UINT, LCID, DISPID *) PURE;
	STDMETHOD_ (ULONG, Invoke)			(THIS_ DISPID, REFIID, LCID, WORD, DISPPARAMS *, VARIANT *, EXCEPINFO *, UINT *) PURE;
	// Extra functions
	STDMETHOD  (SetString)			(THIS_ BSTR) PURE;
	STDMETHOD  (GetString)			(THIS_ BSTR *) PURE;
};

#endif // _IEXAMPLEEXE_H_
