#ifdef __cplusplus
extern "C" {
#endif

// Functions
extern HRESULT	getITypeInfoFromExe(const GUID *, ITypeInfo **); 
extern void		display_COM_error(LPCTSTR, HRESULT);
void			display_sys_error(DWORD);

// Global variables
extern HINSTANCE			InstanceHandle;
extern HWND					MainWindow;

#ifdef __cplusplus
}
#endif
