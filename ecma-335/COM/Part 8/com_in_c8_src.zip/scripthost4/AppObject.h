#ifndef _APPOBJECT_H
#define _APPOBJECT_H

IUnknown *	getAppObject(void);
HRESULT		getAppObjectITypeInfo(ITypeInfo **);
void		initMyRealIAppObject(void);
void		freeMyRealIAppObject(void);

#endif