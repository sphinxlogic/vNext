IDispatch *		allocNetworkObjectsCollection(void);
void			freeNetworkObjectsCollection(void);
HRESULT			initNetworkObjectsCollection(void);
