#ifdef __cplusplus
extern "C" {
#endif

// Functions
extern void		display_COM_error(LPCTSTR, HRESULT);

// Global data
extern IActiveScript	*VBActiveScript;
extern IActiveScript	*JActiveScript;
extern const wchar_t	VBName[];
extern const wchar_t	JName[];

#ifdef __cplusplus
}
#endif
