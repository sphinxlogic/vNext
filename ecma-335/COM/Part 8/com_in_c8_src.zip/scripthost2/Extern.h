#ifdef __cplusplus
extern "C" {
#endif

#include "IActiveScriptSite.h"

// Functions
extern void		display_COM_error(LPCTSTR, HRESULT);
void			display_sys_error(DWORD);
extern int		chooseEngineDlg(GUID *);

// Global variables
extern HINSTANCE				InstanceHandle;
extern HWND						MainWindow;
extern MyRealIActiveScriptSite	MyActiveScriptSite;

#ifdef __cplusplus
}
#endif
