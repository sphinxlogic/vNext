#ifndef _HOSTSITE_H
#define _HOSTSITE_H

#ifdef __cplusplus
extern "C" {
#endif

// The definition of our MyRealIActiveScriptSite multiple interface
// object. It has an IActiveScriptSite object as the base object,
// and an IActiveScriptSiteWindow sub-object.
typedef struct {
	IActiveScriptSite			site;		// The IActiveScriptSite must be the base object.
	IActiveScriptSiteWindow		siteWnd;	// Our IActiveScriptSiteWindow sub-object for this IActiveScriptSite.
} MyRealIActiveScriptSite;

void initIActiveScriptSiteObject(void);

#ifdef __cplusplus
}
#endif

#endif